import polars as pl
from pathlib import Path

print("="*60)
print("SCOTLAND AI SPLIT-ZONES: AUTOMATED STRESS TEST")
print("="*60)

# Load the intermediate data
DATA_INTERMEDIATE = Path("data/intermediate")
absorption_df = pl.read_parquet(DATA_INTERMEDIATE / "renewable_absorption.parquet")

# Filter to Whitelee Wind Farm (Export Constrained)
site_df = absorption_df.filter(pl.col("site_name") == "Whitelee Wind Farm")

print("\n--- STRESS TEST: The Timescale Mismatch Trap ---")
print("Testing a 500 MW AI campus (50% schedulable, 50% curtailment proxy)")
print("Comparing Perfect Match vs. Realistic Intraday Event\n")

# Scenario A: Perfect Match (4h notice, 4h event)
scenario_a = site_df.filter(
    (pl.col("schedulable_fraction") == 0.5) &
    (pl.col("notice_period_h") == 4) &
    (pl.col("event_duration_h") == 4)
)
abs_a = scenario_a["renewable_absorption_mw"].to_list()[0]

# Scenario B: Timescale Mismatch (12h notice, 2h event)
scenario_b = site_df.filter(
    (pl.col("schedulable_fraction") == 0.5) &
    (pl.col("notice_period_h") == 12) &
    (pl.col("event_duration_h") == 2)
)
abs_b = scenario_b["renewable_absorption_mw"].to_list()[0]

print(f"Scenario A (4h Notice / 4h Event):  Absorbs {abs_a:.1f} MW")
print(f"Scenario B (12h Notice / 2h Event): Absorbs {abs_b:.1f} MW")
print("-" * 60)

drop_pct = ((abs_a - abs_b) / abs_a) * 100
print(f"RESULT: Absorption collapses by {drop_pct:.1f}% due to IT timescale mismatch.")
print("CONCLUSION: Static '50% flexibility' claims are physically misleading for intraday events.")
print("="*60)
