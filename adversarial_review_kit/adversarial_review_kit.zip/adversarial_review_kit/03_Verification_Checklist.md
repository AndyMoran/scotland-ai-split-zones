# Code Audit Trail & Verification Checklist

This model is fully reproducible. To verify our findings, follow these steps:

## Prerequisites
- WSL2 (Ubuntu) or native Linux
- `uv` package manager installed
- Python 3.11+

## Step 1: Clone and Environment Setup
```bash
git clone [Insert GitHub URL]
cd scotland-ai-split-zones
uv sync
uv run python adversarial_review_kit/run_stress_tests.py
